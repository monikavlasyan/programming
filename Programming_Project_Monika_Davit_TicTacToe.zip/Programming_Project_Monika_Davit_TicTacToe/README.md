# Tic-Tac-Toe Game
 

This is a terminal-based Tic-Tac-Toe game implemented in C. It allows users to play in two modes: against another player or against a simple AI.
 

## Features
 

\- Two-player mode
 
\- Player vs AI mode
 
\- Simple AI that selects random empty cells
 
\- Highlights the winning line in green (on compatible terminals)
 

## Prerequisites
 

\- A C compiler such as `gcc`
 
\- A Unix-like terminal (for `system("clear")` to work properly)
 

## Compilation
 

To compile the program, open a terminal and navigate to the directory containing `main.c`, then run:
 

\`\`\`bash
 
gcc -o tictactoe main.c