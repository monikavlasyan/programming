#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

// Global board and winning line positions
char board[3][3];
int win_pos[3][2];

// Function prototypes
void initialize_board(void);
void draw_board(void);
bool check_win(char player);
bool check_draw(void);
void player_move(char player);
void ai_move(char player);

int main(void) {
    srand((unsigned)time(NULL));  // Seed for random AI moves
    char mode;
    bool play_again = true;

    while (play_again) {
        initialize_board();

        // Select game mode
        printf("Select mode: 1) Two players  2) Play against AI\n");
        printf("Enter 1 or 2: ");
        scanf(" %c", &mode);

        char current = 'X';
        bool vs_ai = (mode == '2');
        bool game_over = false;

        // Main game loop
        while (!game_over) {
            draw_board();

            if (current == 'O' && vs_ai) {
                ai_move(current);
            } else {
                player_move(current);
            }

            if (check_win(current)) {
                draw_board();
                printf("Player %c wins!\n", current);
                game_over = true;
            } else if (check_draw()) {
                draw_board();
                printf("It's a draw!\n");
                game_over = true;
            } else {
                // Switch player
                current = (current == 'X') ? 'O' : 'X';
            }
        }

        // Play again prompt
        printf("Play again? (Y/N): ");
        char ans;
        scanf(" %c", &ans);
        if (ans != 'Y' && ans != 'y') {
            play_again = false;
        }
    }

    printf("Thanks for playing!\n");
    return 0;
}

// Initialize the board and clear win positions
void initialize_board(void) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            board[i][j] = ' ';
            if (i < 3) win_pos[i][0] = win_pos[i][1] = -1;
        }
    }
}

// Draw the board, highlighting winning line if present
void draw_board(void) {
    system("clear");  // Clear terminal (on Unix-like systems)
    printf("\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            bool highlight = false;
            // Check if this cell is part of the winning line
            for (int k = 0; k < 3; k++) {
                if (win_pos[k][0] == i && win_pos[k][1] == j) {
                    highlight = true;
                    break;
                }
            }
            if (highlight) {
                // Print winning cells in green
                printf(" \033[32m%c\033[0m ", board[i][j]);
            } else {
                printf(" %c ", board[i][j]);
            }
            if (j < 2) printf("|");
        }
        if (i < 2) printf("\n---+---+---\n");
    }
    printf("\n\n");
}

// Check for a win and record winning line positions
bool check_win(char player) {
    // Rows
    for (int i = 0; i < 3; i++) {
        if (board[i][0] == player && board[i][1] == player && board[i][2] == player) {
            for (int j = 0; j < 3; j++) {
                win_pos[j][0] = i;
                win_pos[j][1] = j;
            }
            return true;
        }
    }
    // Columns
    for (int j = 0; j < 3; j++) {
        if (board[0][j] == player && board[1][j] == player && board[2][j] == player) {
            for (int i = 0; i < 3; i++) {
                win_pos[i][0] = i;
                win_pos[i][1] = j;
            }
            return true;
        }
    }
    // Diagonals
    if (board[0][0] == player && board[1][1] == player && board[2][2] == player) {
        for (int k = 0; k < 3; k++) {
            win_pos[k][0] = k;
            win_pos[k][1] = k;
        }
        return true;
    }
    if (board[0][2] == player && board[1][1] == player && board[2][0] == player) {
        for (int k = 0; k < 3; k++) {
            win_pos[k][0] = k;
            win_pos[k][1] = 2 - k;
        }
        return true;
    }
    return false;
}

// Check if the board is full (draw)
bool check_draw(void) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == ' ') {
                return false;
            }
        }
    }
    return true;
}

// Handle player move input and validation
void player_move(char player) {
    int row, col;
    while (true) {
        printf("Player %c, enter row and column (1-3): ", player);
        if (scanf("%d %d", &row, &col) != 2) {
            while (getchar() != '\n');  // Clear invalid input
            printf("Invalid input! Use two numbers. Try again.\n");
            continue;
        }
        row--; col--;
        if (row < 0 || row > 2 || col < 0 || col > 2) {
            printf("Out of bounds! Try again.\n");
        } else if (board[row][col] != ' ') {
            printf("Cell occupied! Try again.\n");
        } else {
            board[row][col] = player;
            break;
        }
    }
}

// Simple AI that picks a random empty cell
void ai_move(char player) {
    int empties[9][2];
    int count = 0;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == ' ') {
                empties[count][0] = i;
                empties[count][1] = j;
                count++;
            }
        }
    }
    if (count > 0) {
        int choice = rand() % count;
        board[empties[choice][0]][empties[choice][1]] = player;
    }
}
